
# 16x2 LCD Display

The following code is for displaying character on 16x2 LCD display. Refer manual for more information.

## Deployment

To deploy this project, copy the code from 16x2_lcd_display.txt and paste in respective position.



## Acknowledgements

THIS IS FOR STM32-L4R5ZI-P board.


## Documentation
NOTE: THE FOLLOWING LINKS/REFERENCE MAY OR MAY NOT BE OF STM32-L4R5ZI-P.

Youtube video reference:

- https://www.youtube.com/watch?v=6C83ViSAYfk

