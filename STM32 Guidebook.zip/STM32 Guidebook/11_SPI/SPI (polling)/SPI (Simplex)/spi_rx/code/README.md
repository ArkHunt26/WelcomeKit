
# SPI Simplex Transmitter Code

The following code is for sending data via SPI protocol on STM32-L4R5ZI-P. Refer manual for more information.

## Deployment

To deploy this project, copy the code from spi_simplex_rx.txt and paste in respective location.  


## Acknowledgements

THIS IS FOR STM32-L4R5ZI-P board.


## Documentation
NOTE: THE FOLLOWING LINKS/REFERENCE MAY OR MAY NOT BE OF STM32-L4R5ZI-P.

Youtube video reference:

- https://www.youtube.com/watch?v=5MYlSn-wR5g&t=283s
- https://www.youtube.com/watch?v=IyGwvGzrqp8&t=596s
- https://www.youtube.com/watch?v=KnuAP7ga5Lw

Website for reference:

- https://community.st.com/t5/stm32-mcu-products/state-spi-ready-hal-driver/td-p/407904
- https://stackoverflow.com/questions/67922914/stm32-spi-communication-with-hal
- https://deepbluembedded.com/how-to-receive-spi-with-stm32-dma-interrupt/
