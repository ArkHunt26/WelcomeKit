
# SPI Simplex Transmitter Code

The following code is for sending data in interrupt form via SPI protocol on STM32-L4R5ZI-P. Refer manual for more information.

## Deployment

To deploy this project, copy the code from spi_interrupt_rx.txt and paste in respective location.  


## Acknowledgements

THIS IS FOR STM32-L4R5ZI-P board.


## Documentation
NOTE: THE FOLLOWING LINKS/REFERENCE MAY OR MAY NOT BE OF STM32-L4R5ZI-P.

Youtube video reference:

- 
- 
