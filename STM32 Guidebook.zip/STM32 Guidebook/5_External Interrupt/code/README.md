
# External Interrupt Code

The following code is for Toggling in-built LED User LD2 PB7 using User Switch acting as an external interrupt on STM32-L4R5ZI-P. Refer manual for more information.

## Deployment

To deploy this project, copy the code from external_interrupt.txt and paste in between 

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */


## Acknowledgements

THIS IS FOR STM32-L4R5ZI-P board.


## Documentation
NOTE: THE FOLLOWING LINKS/REFERENCE MAY OR MAY NOT BE OF STM32-L4R5ZI-P.

Youtube video reference:

- https://www.youtube.com/watch?v=hd6F-tL_UX4
- https://www.youtube.com/watch?v=qd_tevhJ2eE&t=27s