
# Blinking LED

The following code is read ADC value and send the data via UART on STM32-L4R5ZI-P and view it using Docklight. Refer manual for more information.

## Deployment

To deploy this project, copy the code from adc.txt and paste in main();



## Acknowledgements

THIS IS FOR STM32-L4R5ZI-P board.


## Documentation
NOTE: THE FOLLOWING LINKS/REFERENCE MAY OR MAY NOT BE OF STM32-L4R5ZI-P.

Youtube video reference:

- https://www.youtube.com/watch?v=s_KdPqAzGrk

Websites:

- 
