
# UART Code

The following code is to read the data from 4x4 keypad and display the data via UART communication protocol on STM32-L4R5ZI-P. To view the data use Docklight. Refer manual for more information.

## Deployment

To deploy this project, copy the code from keypad_4x4.txt and paste in while() 


## Acknowledgements

THIS IS FOR STM32-L4R5ZI-P board.


## Documentation
NOTE: THE FOLLOWING LINKS/REFERENCE MAY OR MAY NOT BE OF STM32-L4R5ZI-P.

Youtube video reference:
- https://www.youtube.com/watch?v=xs-2kqyzmPU

Websites for reference:

-  