
# Switch Interface Code

The following code is to turn ON in-built LED User LD2 PB7 using User Switch PC13 on STM32-L4R5ZI-P. Refer manual for more information.

## Deployment

To deploy this project, copy the code from switch_interface.txt and paste in main() 


## Acknowledgements

THIS IS FOR STM32-L4R5ZI-P board.


## Documentation
NOTE: THE FOLLOWING LINKS/REFERENCE MAY OR MAY NOT BE OF STM32-L4R5ZI-P.

Youtube video reference:

- https://www.youtube.com/watch?v=sqBGjR3MTEU

- https://www.youtube.com/watch?v=53A_7XBlvsQ

