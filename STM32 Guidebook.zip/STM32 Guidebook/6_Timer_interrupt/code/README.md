
# Timer Interrupt Code

The following code is for Toggling in-built LED User LD2 PB7 using with respect to timer interrupt of 1 second on STM32-L4R5ZI-P. Refer manual for more information.

## Deployment

To deploy this project, copy the code from timer_interrupt.txt and paste in between 

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */


## Acknowledgements

THIS IS FOR STM32-L4R5ZI-P board.


## Documentation
NOTE: THE FOLLOWING LINKS/REFERENCE MAY OR MAY NOT BE OF STM32-L4R5ZI-P.

Youtube video reference:

- https://www.youtube.com/watch?v=YPJlhYm5T8Y
- https://www.youtube.com/watch?v=quZWGSEMyD0&list=PLaSBRRMONZaaTOlA4T7OZw6fIEsmMM9fa&index=30
