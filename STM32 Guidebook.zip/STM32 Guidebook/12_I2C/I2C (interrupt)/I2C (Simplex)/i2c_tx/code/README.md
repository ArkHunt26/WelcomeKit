
# SPI Simplex Transmitter Code

The following code is for sending data via I2C protocol on STM32-L4R5ZI-P. Refer manual for more information.

## Deployment

To deploy this project, copy the code from i2c_tx.txt and paste in respective location.  


## Acknowledgements

THIS IS FOR STM32-L4R5ZI-P board.


## Documentation
NOTE: THE FOLLOWING LINKS/REFERENCE MAY OR MAY NOT BE OF STM32-L4R5ZI-P.

Youtube video reference:

- 

Website reference:

- https://wiki.st.com/stm32mcu/wiki/Getting_started_with_I2C