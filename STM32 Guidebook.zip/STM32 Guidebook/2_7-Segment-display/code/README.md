
# 7-Segment Display

The following code is for running a 7-segment display that counts from 0 to 9 with 1 second interval. Refer manual for more information.

## Deployment

To deploy this project, copy the code from 7-segment.txt and paste in main();



## Acknowledgements

THIS IS FOR STM32-L4R5ZI-P board.


## Documentation
NOTE: THE FOLLOWING LINKS/REFERENCE MAY OR MAY NOT BE OF STM32-L4R5ZI-P.

Youtube video reference:

- https://www.youtube.com/watch?v=oIQSO0Vyvdc

