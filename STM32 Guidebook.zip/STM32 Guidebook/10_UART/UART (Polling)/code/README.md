
# UART Code

The following code is receiving and transmitting data via UART communication protocol on STM32-L4R5ZI-P. To view and transmit the data use Docklight. Refer manual for more information.

## Deployment

To deploy this project, copy the code from uart.txt and paste in while() 


## Acknowledgements

THIS IS FOR STM32-L4R5ZI-P board.


## Documentation
NOTE: THE FOLLOWING LINKS/REFERENCE MAY OR MAY NOT BE OF STM32-L4R5ZI-P.

Youtube video reference:

- https://www.youtube.com/watch?v=ic7hCrDopOQ
- https://www.youtube.com/watch?v=l5msGz2tZP0

Websites for reference:

- https://www.youtube.com/watch?v=l5msGz2tZP0 