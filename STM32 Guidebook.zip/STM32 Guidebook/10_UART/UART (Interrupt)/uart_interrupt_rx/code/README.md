
# UART Code

The following code is receiving data as interrupt and transmitting the data using polling method via UART communication protocol on STM32-L4R5ZI-P. To view the data use Docklight. Refer manual for more information.

## Deployment

To deploy this project, copy the code from uart_interrupt_rx.txt and paste in the respective positions. 


## Acknowledgements

THIS IS FOR STM32-L4R5ZI-P board.


## Documentation
NOTE: THE FOLLOWING LINKS/REFERENCE MAY OR MAY NOT BE OF STM32-L4R5ZI-P.

Youtube video reference:

- 

Websites for reference:

-  https://wiki.st.com/stm32mcu/wiki/Getting_started_with_UART